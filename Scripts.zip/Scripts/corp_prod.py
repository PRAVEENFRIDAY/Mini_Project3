# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import streamlit as st
import plotly.express as px

# Load the dataset
@st.cache_data

def load_data(chunk_size=10000):
    """Load large CSV file in chunks and concatenate."""
    file_path = "C:/Users/user/Downloads/FAOSTAT_cleaned_data1.csv"  # Update with actual file path
    chunk_list = []  # List to store chunks
    
    try:
        # Read CSV in chunks
        for chunk in pd.read_csv(file_path, chunksize=chunk_size):
            chunk_list.append(chunk)  # Append chunk to list
        
        # Combine all chunks into a single DataFrame
        data = pd.concat(chunk_list, ignore_index=True)
        return data

    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        return None


# Data Cleaning and Preprocessing
def clean_data(data):
    if data is None:
        st.error("Error: Data could not be loaded. Check the file path and format.")
        return None  # Stop further execution

    # Drop unnecessary columns
    columns_to_drop = ["Domain", "Area Code", "Item Code", "Year Code", "Carcass Weight", 
                       "Laying", "Milk Animals", "Producing Animals/Slaughtered", "Stocks"]
    data = data.drop(columns=columns_to_drop, errors='ignore')

    # Check column names before renaming
    st.write("Columns before renaming:", data.columns.tolist())

    # Strip spaces from column names
    data.columns = data.columns.str.strip()

    # Rename columns correctly
    data = data.rename(columns={
        "Area": "Region",
        "Item": "Crop",
        "Year": "Year",
        "Area harvested": "Area_harvested",
        "Production": "Production",
        "Yield": "Yield"
    })  

    # Ensure column names are consistent
    data.columns = data.columns.str.replace(" ", "_")

    # Handle missing values by filling with median values
    numeric_cols = ["Area_harvested", "Production", "Yield"]
    for col in numeric_cols:
        if col in data.columns:
            data[col] = data[col].fillna(data[col].median())
        else:
            st.warning(f"Column {col} not found in data.")

    return data




# Exploratory Data Analysis (EDA)
def perform_eda(data):
    st.subheader("Exploratory Data Analysis (EDA)")
    st.write("Basic Statistics:", data.describe())


    # Distribution of Crops (Top 10)
    st.write("### Distribution of Crops (Top 10)")
    top_crops = data['Crop'].value_counts().nlargest(10)  # Show top 10 crops
    fig, ax = plt.subplots(figsize=(10, 6))
    top_crops.plot(kind='bar', ax=ax, color='skyblue')
    ax.set_title('Top 10 Crops by Count')
    ax.set_xlabel('Crop')
    ax.set_ylabel('Count')
    ax.tick_params(axis='x', rotation=45)  # Rotate x-axis labels
    st.pyplot(fig)

    # Yearly Trends (Top 5 Crops)
    st.write("### Yearly Trends (Top 5 Crops)")
    top_crops_list = data['Crop'].value_counts().nlargest(5).index.tolist()  # Get top 5 crops
    filtered_data = data[data['Crop'].isin(top_crops_list)]  # Filter data for top 5 crops

    fig, ax = plt.subplots(figsize=(12, 6))
    sns.lineplot(x='Year', y='Production', hue='Crop', data=filtered_data, ax=ax, palette='tab10')
    ax.set_title('Yearly Production Trends for Top 5 Crops')
    ax.set_xlabel('Year')
    ax.set_ylabel('Production')
    ax.legend(title='Crop', bbox_to_anchor=(1.05, 1), loc='upper left')  # Move legend outside
    st.pyplot(fig)

    # Temporal Analysis (Aggregated by Year)
    st.write("### Temporal Analysis (Aggregated by Year)")
    yearly_trends = data.groupby("Year")[["Area_harvested", "Yield", "Production"]].mean()

    # Plot each metric separately
    st.write("#### Area Harvested Over Time")
    st.line_chart(yearly_trends['Area_harvested'])

    st.write("#### Yield Over Time")
    st.line_chart(yearly_trends['Yield'])

    st.write("#### Production Over Time")
    st.line_chart(yearly_trends['Production'])




    # Crop Distribution - Limit to Top 20
    st.write("### Top 20 Most Frequent Crops")
    crop_counts = data["Crop"].value_counts().head(20)  # Show top 20 crops
    fig, ax = plt.subplots(figsize=(12, 6))
    sns.barplot(x=crop_counts.index, y=crop_counts.values, ax=ax, palette="Blues_r")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")  # Rotate labels
    ax.set_title("Top 20 Crops by Frequency")
    st.pyplot(fig)

    # Geographical Distribution - Limit to Top 20
    st.write("### Top 20 Regions by Frequency")
    region_counts = data["Region"].value_counts().head(20)
    fig, ax = plt.subplots(figsize=(12, 6))
    sns.barplot(x=region_counts.index, y=region_counts.values, ax=ax, palette="Greens_r")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
    ax.set_title("Top 20 Regions by Frequency")
    st.pyplot(fig)

    # Yearly Trends - Aggregate for Clarity
    st.write("### Yearly Trends (Averaged Across Crops)")
    yearly_trends = data.groupby("Year")[["Production"]].sum()  # Sum production per year
    fig, ax = plt.subplots(figsize=(10, 5))
    sns.lineplot(data=yearly_trends, marker="o", ax=ax)
    ax.set_title("Yearly Production Trends")
    st.pyplot(fig)

    # Correlation Analysis - Improve Visibility
    st.write("### Correlation Matrix")
    corr_matrix = data[["Area_harvested", "Yield", "Production"]].corr()
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5, ax=ax)
    ax.set_title("Feature Correlation Matrix")
    st.pyplot(fig)

    # Outlier Detection - Adjust for Readability
    st.write("### Outlier Detection")
    fig, ax = plt.subplots(1, 3, figsize=(15, 5))
    sns.boxplot(y=data["Area_harvested"], ax=ax[0], color="lightblue")
    sns.boxplot(y=data["Yield"], ax=ax[1], color="lightgreen")
    sns.boxplot(y=data["Production"], ax=ax[2], color="salmon")

    ax[0].set_title("Area Harvested")
    ax[1].set_title("Yield")
    ax[2].set_title("Production")

    st.pyplot(fig)

    data = data.sample(frac=0.1, random_state=42)  # Sample 10% of the data

    
    fig = px.line(filtered_data, x='Year', y='Production', color='Crop', title='Yearly Production Trends')
    st.plotly_chart(fig)

    g = sns.FacetGrid(filtered_data, col='Crop', col_wrap=3, height=4, sharey=False)
    g.map(sns.lineplot, 'Year', 'Production')
    st.pyplot(g)






# Feature Engineering
def feature_engineering(data):
    label_encoder = LabelEncoder()
    data['Crop'] = label_encoder.fit_transform(data['Crop'])
    data['Region'] = label_encoder.fit_transform(data['Region'])
    return data


def optimize_memory_usage(data):
    for col in data.select_dtypes(include=["int64", "float64"]).columns:
        data[col] = pd.to_numeric(data[col], downcast="float")
    return data

# Model Building and Evaluation
def build_model(data):
    try:
        st.subheader("Model Building and Evaluation")

        # Process data in chunks
        chunk_list = []
        for chunk in np.array_split(data, 10):  # Split into smaller parts
            chunk = optimize_memory_usage(chunk)  # Optimize memory usage
            chunk_list.append(chunk)

        data = pd.concat(chunk_list, ignore_index=True)  # Recombine chunks

        # Optimize memory usage
        data = optimize_memory_usage(data)

        # Reduce dataset size (optional)
        data = data.sample(frac=0.5, random_state=42)  # Use only 50% of data

        X = data[["Area_harvested", "Yield", "Year"]]
        y = data["Production"]

        # Handle missing values
        X.fillna(X.mean(), inplace=True)
        y.fillna(y.mean(), inplace=True)

        # Train-Test Split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Standardize Features
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

        # Model Selection
        models = {
            "Linear Regression": LinearRegression(),
            "Random Forest": RandomForestRegressor(random_state=42, n_estimators=10),  # Reduce estimators
            "Gradient Boosting": GradientBoostingRegressor(random_state=42, n_estimators=10)  # Reduce estimators
        }

        results = {}
        best_model = None
        best_score = -np.inf

        for name, model in models.items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            score = r2_score(y_test, y_pred)

            results[name] = {
                "R2 Score": score,
                "MSE": mean_squared_error(y_test, y_pred),
                "MAE": mean_absolute_error(y_test, y_pred)
            }

            if score > best_score:
                best_score = score
                best_model = model

        # Display Results
        st.write("### Model Performance")
        results_df = pd.DataFrame(results).T
        st.table(results_df)

        if best_model is None:
            st.error("No valid model trained. Returning default model.")
            return LinearRegression(), scaler  # Default model if none worked

        return best_model, scaler

    except Exception as e:
        st.error(f"Error in model training: {str(e)}")
        return None, None


# Streamlit Application
def main():
    st.title("Predicting Crop Production Based on Agricultural Data")

    # Load Data
    # Load and clean data
    data = load_data(chunk_size=5000)
    if data is None:
        return  # Exit the function to prevent further execution
        
    
    #cleaned_data = clean_data(data)
    st.write(data)

    # Data Cleaning
    st.subheader("Data Cleaning and Preprocessing")
    cleaned_data = clean_data(data)
    st.write(cleaned_data.head())

    # EDA
    perform_eda(cleaned_data)

    data = optimize_memory_usage(data)
    # Feature Engineering

    # Model Building
    model, scaler = build_model(cleaned_data)

    if model is None or scaler is None:
        st.error("Model training failed. Please check data preprocessing and ensure required columns exist.")
        return  # Exit the function to prevent further execution

    # Prediction Interface
    st.subheader("Crop Production Prediction")
    region = st.selectbox("Select Region", cleaned_data["Region"].unique())
    crop = st.selectbox("Select Crop", cleaned_data["Crop"].unique())
    year = st.number_input("Enter Year", min_value=2000, max_value=2030, value=2023)
    area_harvested = st.number_input("Enter Area Harvested (ha)", min_value=0.0)
    yield_value = st.number_input("Enter Yield (kg/ha)", min_value=0.0)

    if st.button("Predict Production"):
        input_data = np.array([[area_harvested, yield_value, year]])
        input_data_scaled = scaler.transform(input_data)
        prediction = model.predict(input_data_scaled)
        st.write(f"**Predicted Production:** {prediction[0]:.2f} tons")

# Run the Streamlit App
if __name__ == "__main__":
    main()